/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebainicial;

import java.util.ArrayList;

/**
 *
 * @author daw2
 */
public class GestorTareas {

    private ArrayList<Tarea> lista;

    public GestorTareas() {
        this.lista=new ArrayList<>();
    }

    public void registrar(String nombre, String asignatura) {
        Tarea t = new Tarea(nombre, asignatura);
        if(lista.add(t)){
            System.out.println("Se agregó correctamente la tarea");
        }else{
            System.out.println("NO se pudo agregar la tarea");
        }
    }

    public void marcarCompletada(String nombre, String asignatura) {
        if (lista.isEmpty()) {
            System.out.println("La lista está vacía");
        } else {
            for (Tarea tarea : lista) {
                if (tarea.getNombre().equalsIgnoreCase(nombre) && tarea.getAsignatura().equalsIgnoreCase(asignatura)) {
                    tarea.setCompletada();
                    System.out.println("Se marcó como completada");
                }
            }
        }
    }

    public void listar() {
        if (lista.isEmpty()) {
            System.out.println("La lista está vacía");
        } else {
            for (Tarea tarea : lista) {
                System.out.println(tarea.toString());
            }
        }
    }

    public void eliminar(String nombre, String asignatura) {
        boolean eliminar=false;
        if (lista.isEmpty()) {
            System.out.println("La lista está vacía");
        } else {
            for (Tarea tarea : lista) {
                if (tarea.getNombre().equalsIgnoreCase(nombre) && tarea.getAsignatura().equalsIgnoreCase(asignatura)) {
                    lista.remove(tarea);
                    System.out.println("Se eliminó correctamente");
                     eliminar=true;
                }
            }
            if(eliminar=false){
                System.out.println("Error al eliminar");
            }
        }
    }

}
