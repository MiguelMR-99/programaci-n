/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.pruebainicial;

import java.util.Scanner;

/**
 *
 * @author daw2
 */
public class PruebaInicial {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        GestorTareas gestor = new GestorTareas();
        int n = 0;
        String nombre;
        String asignatura;

        do {
            try {
                do {
                    System.out.println("1- Registrar nueva tarea");
                    System.out.println("2- Marcar tarea como completada");
                    System.out.println("3- Lista de tareas");
                    System.out.println("4- Eliminar tarea");
                    System.out.println("5- Salir\n");
                    System.out.println("Introduce la opcion deseada: ");
                    n = teclado.nextInt();

                } while (n < 1 || n > 5);
            } catch (NumberFormatException e) {
                System.out.println("No has introducido un numero.");
            }

            switch (n) {
                case 1:
                    System.out.println("INtroduce el nombre de la tarea: ");
                    nombre=teclado.nextLine();
                    System.out.println("Introduce el nombre de la asignatura: ");
                    asignatura=teclado.nextLine();
                    gestor.registrar(nombre, asignatura);
                    break;
                case 2:
                    System.out.println("INtroduce el nombre de la tarea: ");
                    nombre=teclado.nextLine();
                    System.out.println("Introduce el nombre de la asignatura: ");
                    asignatura=teclado.nextLine();
                    gestor.marcarCompletada(nombre, asignatura);
                    
                    break;
                case 3:
                    gestor.listar();
                    break;
                case 4:
                    System.out.println("INtroduce el nombre de la tarea: ");
                    nombre=teclado.nextLine();
                    System.out.println("Introduce el nombre de la asignatura: ");
                    asignatura=teclado.nextLine();
                    gestor.eliminar(nombre, asignatura);
                    break;
                case 5:
                    System.out.println("Saliendo del programa...");
                    break;

            }

        } while (n != 5);
        
        teclado.close();

    }
}
