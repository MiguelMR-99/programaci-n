/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebainicial;

/**
 *
 * @author daw2
 */
public class Tarea {

    String nombre;
    String asignatura;
    boolean completada;
    
    public Tarea(String nombre, String asignatura) {
        this.nombre=nombre;
        this.asignatura=asignatura;
        this.completada=false;
    }

    @Override
    public String toString() {
        return "Tarea{" + "nombre=" + nombre + ", asignatura=" + asignatura + '}';
    }

    public void setCompletada() {
        this.completada = true;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAsignatura() {
        return asignatura;
    }
    
    
    
    
}
